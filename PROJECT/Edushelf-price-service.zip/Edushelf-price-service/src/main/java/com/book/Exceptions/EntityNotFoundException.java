package com.book.Exceptions;

public class EntityNotFoundException extends RuntimeException {

}
