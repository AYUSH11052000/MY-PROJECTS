package com.book.services;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.book.dto.PriceRequest;
import com.book.dto.PriceResponse;
import com.book.entity.Price;
import com.book.repository.PriceRepository;
import jakarta.persistence.EntityNotFoundException;
@Service
public class PriceService {
    @Autowired
    private PriceRepository priceRepository;
    @Autowired
    private ModelMapper modelMapper;   
    public PriceResponse convertToResponse(Price price) {
        if (price == null) {
            throw new IllegalArgumentException("Price cannot be null");
        }
        return modelMapper.map(price, PriceResponse.class);
    }
    public PriceResponse addPrice(PriceRequest request) {
    	Optional<Price> existingPrice = priceRepository.findDynamicPrice(request.getProductId(), request.getSku(),
                request.getCustomerGroup(),
                request.getCountry(),
                request.getCurrency());
                if (existingPrice.isPresent()) {
                throw new IllegalArgumentException("Duplicate price configuration found for the given parameters.");
   }
              Price price = modelMapper.map(request, Price.class);
              Price saved = priceRepository.save(price);
             return convertToResponse(saved);
}
    public PriceResponse updatePrice(Long id, PriceRequest request) {
        Price price = priceRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Price not found")); 
        modelMapper.map(request, price);
        Price updated = priceRepository.save(price);
        return convertToResponse(updated);
    }
    public void deletePrice(Long id) {
        priceRepository.deleteById(id);
    }
    public List<PriceResponse> getPricesByProduct(Long productId) {
        return priceRepository.findByProductId(productId).stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }
 public PriceResponse getPrice(String sku) {
	 Price price=priceRepository.findFirstBySku(sku);
	
	 return convertToResponse(price);
 }
 private BigDecimal fetchBasePriceBySku(String sku) {
	    Price price = priceRepository.findFirstBySku(sku);
	    return price != null ? price.getPriceAmount() : null;
	} 
 
}
