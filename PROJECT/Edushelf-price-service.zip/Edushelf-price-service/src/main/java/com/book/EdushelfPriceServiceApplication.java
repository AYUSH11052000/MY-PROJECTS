package com.book;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
public class EdushelfPriceServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EdushelfPriceServiceApplication.class, args);
	}

}
