package com.EduShelf.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.EduShelf.DTO.PriceRequest;
import com.EduShelf.DTO.PriceResponse;
import com.EduShelf.model.Price;
import com.EduShelf.repositories.PriceRepository;
import com.EduShelf.services.PricingService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/price")
public class PriceController {

	@Autowired
	private PricingService pricingService;

	@PostMapping
	public ResponseEntity<Price> createPrice(@RequestBody Price price) {
		return new ResponseEntity<Price>(pricingService.createPrice(price), HttpStatus.CREATED);
	}

	@GetMapping("/SKU/{sku}")
	public ResponseEntity<Price> findPriceBySku(@PathVariable("sku") String sku) {
		return new ResponseEntity<Price>(pricingService.getPrice(sku), HttpStatus.OK);
	}
//	@PostMapping
//	public ResponseEntity<PriceResponse> addPrice(@RequestBody @Valid PriceRequest request) {
//		return new ResponseEntity<PriceResponse>(priceService.addPrice(request), HttpStatus.CREATED);
//	}

	@PutMapping("/{id}")
	public ResponseEntity<PriceResponse> updatePrice(@PathVariable Long id, @RequestBody @Valid PriceRequest request) {
		return ResponseEntity.ok(pricingService.updatePrice(id, request));
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deletePrice(@PathVariable Long id) {
		pricingService.deletePrice(id);
		return ResponseEntity.noContent().build();
	}

	@GetMapping("/{productId}")
	public ResponseEntity<List<PriceResponse>> getPricesByProduct(@PathVariable Long productId) {
		return ResponseEntity.ok(pricingService.getPricesByProduct(productId));
	}
	@GetMapping("/dynamic")
	public ResponseEntity<PriceResponse> getDynamicPrice(@RequestParam String productId, @RequestParam String sku,
			@RequestParam(required = false) String customerGroup, @RequestParam(required = false) String country,
			@RequestParam String currency) {
		return ResponseEntity.ok(pricingService.getDynamicPrice(sku, customerGroup, country, currency, currency));
	}

//	@GetMapping("/dynamic")
//	public ResponseEntity<PriceResponse> getDynamicPrice(@RequestParam Long productId, @RequestParam String sku,
//			@RequestParam(required = false) String customerGroup, @RequestParam(required = false) String country,
//			@RequestParam String currency) {
//		return ResponseEntity.ok(pricingService.getDynamicPrice(productId, sku, customerGroup, country, currency));
//	}

}
