package com.EduShelf.openfeigns;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.EduShelf.DTO.ProductResponseDTO;
import com.EduShelf.model.Product;

@FeignClient(name = "EduShelf-Product-Service",url="https://localhost:7899/product")
public interface ProductServiceFeign {
	
	@GetMapping("/api/product/{id}")
	public ResponseEntity<ProductResponseDTO> getById(@PathVariable("id") Long id) ;
}
