package com.EduShelf.openfeigns;

import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "EduShelf-Customer-Service",url="https://localhost:7899/")
public interface CustomerServiceFeign {

}
