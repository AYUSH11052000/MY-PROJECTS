package com.EduShelf.exceptions;

public class GlobalExceptionHandler {

}
