package com.EduShelf.model;

public enum AttributeType {
	TEXT,
	NUMBER,
	ENUM,
	DATE

}
