package com.EduShelf.model;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;


public class ProductType {

	
	private long id;
	private String name;
	private String description;

	List<AttributeDefinition> attributes = new ArrayList<>();

	public ProductType() {
		super();
	}

	public ProductType(String name, String description) {
		super();
		this.name = name;
		this.description = description;
	}

	public ProductType(long id, String name, String description) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<AttributeDefinition> getAttributes() {
		return attributes;
	}

	public void setAttributes(List<AttributeDefinition> attributes) {
		this.attributes = attributes;
	}

	@Override
	public String toString() {
		return "ProductType [id=" + id + ", name=" + name + ", description=" + description + ", attributes="
				+ attributes + "]";
	}

}
