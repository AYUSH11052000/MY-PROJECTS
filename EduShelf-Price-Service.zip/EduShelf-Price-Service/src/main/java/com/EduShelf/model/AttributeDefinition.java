package com.EduShelf.model;

import java.util.List;

import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;


public class AttributeDefinition {

	private long attributeId;
	
	private String attributeName;
	
	@Enumerated(EnumType.STRING)
	private AttributeType type;
	
	@ElementCollection
	private List<String>allowedValues;
 
	public AttributeDefinition() {
		super();
	}

	public long getAttributeId() {
		return attributeId;
	}
 
	public void setAttributeId(long attributeId) {
		this.attributeId = attributeId;
	}
 
	public String getAttributeName() {
		return attributeName;
	}
 
	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}
 
	public AttributeType getType() {
		return type;
	}
 
	public void setType(AttributeType type) {
		this.type = type;
	}
 
	public List<String> getAllowedValues() {
		return allowedValues;
	}
 
	public void setAllowedValues(List<String> allowedValues) {
		this.allowedValues = allowedValues;
	}
 
	public AttributeDefinition(long attributeId, String attributeName, AttributeType type, List<String> allowedValues) {
		super();
		this.attributeId = attributeId;
		this.attributeName = attributeName;
		this.type = type;
		this.allowedValues = allowedValues;
	}
 
	public AttributeDefinition(String attributeName, AttributeType type, List<String> allowedValues) {
		super();
		this.attributeName = attributeName;
		this.type = type;
		this.allowedValues = allowedValues;
	}

}
