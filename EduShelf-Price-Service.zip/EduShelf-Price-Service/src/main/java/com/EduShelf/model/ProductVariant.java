package com.EduShelf.model;

import java.math.BigDecimal;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

public class ProductVariant {

	
	private Long id;
	
	 @Column(unique = true)
	private String sku;
	
	private Integer stock;
	private BigDecimal additionalPrice;
	
	@ElementCollection
	private Map<String, String> variantAttributes;
	
	@JsonBackReference
	private Product product;

	public ProductVariant() {
		super();
	}

	public ProductVariant(String sku, Integer stock, BigDecimal additionalPrice,
			Map<String, String> variantAttributes) {
		super();
		this.sku = sku;
		this.stock = stock;
		this.additionalPrice = additionalPrice;
		this.variantAttributes = variantAttributes;
	}

	public ProductVariant(Long id, String sku, Integer stock, BigDecimal additionalPrice,
			Map<String, String> variantAttributes) {
		super();
		this.id = id;
		this.sku = sku;
		this.stock = stock;
		this.additionalPrice = additionalPrice;
		this.variantAttributes = variantAttributes;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public Integer getStock() {
		return stock;
	}

	public void setStock(Integer stock) {
		this.stock = stock;
	}

	public BigDecimal getAdditionalPrice() {
		return additionalPrice;
	}

	public void setAdditionalPrice(BigDecimal additionalPrice) {
		this.additionalPrice = additionalPrice;
	}

	public Map<String, String> getVariantAttributes() {
		return variantAttributes;
	}

	public void setVariantAttributes(Map<String, String> variantAttributes) {
		this.variantAttributes = variantAttributes;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	@Override
	public String toString() {
		return "ProductVariant [id=" + id + ", sku=" + sku + ", stock=" + stock + ", additionalPrice=" + additionalPrice
				+ ", variantAttributes=" + variantAttributes + "]";
	}

}//ALTER TABLE product_variant ALTER COLUMN product_id DROP NOT NULL;

