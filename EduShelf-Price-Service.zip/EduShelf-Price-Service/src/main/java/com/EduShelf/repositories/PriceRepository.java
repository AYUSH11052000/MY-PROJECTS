package com.EduShelf.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.EduShelf.model.Price;

@Repository
public interface PriceRepository extends JpaRepository<Price, Long> {
	
	Price findFirstBySku(String sku);
	 List<Price> findByProductId(Long productId);
	
	 @Query("SELECT p FROM Price p WHERE p.productId = :productId AND p.sku = :sku AND " +
	            "(:customerGroup IS NULL OR p.customerGroup = :customerGroup) AND " +
	            "(:country IS NULL OR p.country = :country) AND p.currency = :currency")
	     Optional<Price> findDynamicPrice(@Param("productId") long productIdLong, 
	                                      @Param("sku") String sku, 
	                                      @Param("customerGroup") String customerGroup, 
	                                      @Param("country") String country,
	                                      @Param("currency") String currency);
	 @Query("SELECT COUNT(p) FROM Price p WHERE p.sku = :sku AND p.country = :country AND p.currency = :currency")
		long countBySkuCountryCurrency(@Param("sku") String sku, @Param("country") String country, @Param("currency") String currency);
	}



