package com.EduShelf.services;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.EduShelf.DTO.PriceRequest;
import com.EduShelf.DTO.PriceResponse;
import com.EduShelf.DTO.ProductResponseDTO;
import com.EduShelf.exceptions.ResourceNotFoundException;
import com.EduShelf.model.Price;
import com.EduShelf.openfeigns.ProductServiceFeign;
import com.EduShelf.repositories.PriceRepository;

@Service
public class PricingService {

	@Autowired
	private PriceRepository priceRepository;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private ProductServiceFeign productServiceFeign;

	public Price createPrice(Price price) {
//		ResponseEntity<ProductResponseDTO> response = productServiceFeign.getById(price.getProductId());
//		if (response != null) {
			return priceRepository.save(price);
//		} else {
//			throw new ResourceNotFoundException("Product not found for this Id");
//		}
	}

	public Price getPrice(String sku) {
		Price price = priceRepository.findFirstBySku(sku);
		return price;
	}

	public PriceResponse convertToResponse(Price price) {
		if (price == null) {
			throw new IllegalArgumentException("Price cannot be null");
		}
		return modelMapper.map(price, PriceResponse.class);
	}

	public PriceResponse addPrice(PriceRequest request) {
		 
		    try {
		        // Check for duplicates
		        long existingCount = priceRepository.countBySkuCountryCurrency(
		                request.getSku(), request.getCountry(), request.getCurrency());

		        if (existingCount > 0) {
		            throw new IllegalArgumentException("Price already exists for this SKU, country, and currency.");
		        }

		        Price price = new Price();
		        price.setSku(request.getSku());
		        price.setCountry(request.getCountry());
		        price.setCurrency(request.getCurrency());

		        // Apply discount for prime customers
		        BigDecimal priceAmount = request.getPriceAmount();
		        if ("prime".equalsIgnoreCase(request.getCustomerGroup())) {
		            BigDecimal discount = priceAmount.multiply(BigDecimal.valueOf(0.1)); // 10% discount
		            priceAmount = priceAmount.subtract(discount);
		        }
		        price.setPriceAmount(priceAmount);
		        price.setCustomerGroup(request.getCustomerGroup());

		        price = priceRepository.save(price);

		        // Manually map Price to PriceResponse
		        PriceResponse response = new PriceResponse();
		        response.setId(price.getId());
		        response.setSku(price.getSku());
		        response.setCountry(price.getCountry());
		        response.setCurrency(price.getCurrency());
		        response.setPriceAmount(price.getPriceAmount());
		        response.setCustomerGroup(price.getCustomerGroup());

		        return response;

		    } catch (IllegalArgumentException e) {
		        throw e; // For duplicate cases
		    } catch (Exception e) {
		        throw new RuntimeException("Failed to add price", e);
		    }
		}

	public PriceResponse updatePrice(Long id, PriceRequest request) {
		Price price = priceRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Price not found"));
		modelMapper.map(request, price);
		Price updated = priceRepository.save(price);
		return convertToResponse(updated);
	}

	public void deletePrice(Long id) {
		priceRepository.deleteById(id);
	}

	public List<PriceResponse> getPricesByProduct(Long productId) {
		return priceRepository.findByProductId(productId).stream().map(this::convertToResponse)
				.collect(Collectors.toList());
	}
	
	// Change method visibility to 'public' so it can be accessed outside the class
	public PriceResponse getDynamicPrice(String productId,String sku, String customerGroup, String country, String currency) {
		// Implement the logic for fetching the dynamic price here
		long productIdLong = Long.parseLong(productId);
		Optional<Price> price = priceRepository.findDynamicPrice(productIdLong,sku, customerGroup, country, currency);
		if (price.isPresent()) {
			return convertToResponse(price.get());
		} else {
			throw new ResourceNotFoundException("No dynamic price found for the given parameters");
		}
	}

	public void deletePrice(String sku) {
		// Implement price deletion logic based on SKU
		Price price = priceRepository.findFirstBySku(sku);
		if (price != null) {
			priceRepository.delete(price);
		} else {
			throw new ResourceNotFoundException("Price not found for the given SKU");
		}
	}

	private BigDecimal fetchBasePriceBySku(String sku) {
		Price price = priceRepository.findFirstBySku(sku);
		return price != null ? price.getPriceAmount() : null;
	}
}
