package com.EduShelf.DTO;

import java.util.ArrayList;
import java.util.List;

import com.EduShelf.model.Category;
import com.EduShelf.model.ProductType;
import com.EduShelf.model.ProductVariant;

public class ProductResponseDTO {

	private Long id;
	private String productName;
	private String genre;
	private String author;
	private String language;
	private ProductType productType;
	private List<Category> categories = new ArrayList<>();
	private List<ProductVariant> variants = new ArrayList<>();
	public ProductResponseDTO() {
		super();
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public ProductType getProductType() {
		return productType;
	}
	public void setProductType(ProductType productType) {
		this.productType = productType;
	}
	public List<Category> getCategories() {
		return categories;
	}
	public void setCategories(List<Category> categories) {
		this.categories = categories;
	}
	public List<ProductVariant> getVariants() {
		return variants;
	}
	public void setVariants(List<ProductVariant> variants) {
		this.variants = variants;
	}

}
